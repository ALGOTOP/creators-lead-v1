const express = require("express");
const db = require("../db");

const router = express.Router();

router.get("/stats/dashboard", (_req, res) => {
  const leads = db.listLeads();

  const withScore = leads.filter((l) => l.thumbnailScore != null);
  const hot = withScore.filter((l) => l.thumbnailScore <= 4).length;
  const avgScore = withScore.length
    ? Math.round((withScore.reduce((sum, l) => sum + l.thumbnailScore, 0) / withScore.length) * 10) / 10
    : null;

  const byStatus = {
    not_contacted: leads.filter((l) => l.status === "not_contacted").length,
    dm_sent: leads.filter((l) => l.status === "dm_sent").length,
    replied: leads.filter((l) => l.status === "replied").length,
    closed: leads.filter((l) => l.status === "closed").length,
  };

  const byNiche = {};
  for (const l of leads) {
    const key = l.niche || "unspecified";
    byNiche[key] = (byNiche[key] || 0) + 1;
  }

  res.json({
    totalLeads: leads.length,
    hotLeads: hot,
    avgThumbnailScore: avgScore,
    scoredCount: withScore.length,
    unscored: leads.length - withScore.length,
    ...byStatus,
    byNiche: Object.entries(byNiche).map(([niche, count]) => ({ niche, count })),
  });
});

module.exports = router;
