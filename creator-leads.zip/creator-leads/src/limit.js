// Minimal concurrency limiter so we don't need the p-limit package for
// one function. Runs `items` through `worker` with at most `concurrency`
// in flight at once.
async function mapWithConcurrency(items, concurrency, worker) {
  const results = new Array(items.length);
  let nextIndex = 0;

  async function runNext() {
    const i = nextIndex++;
    if (i >= items.length) return;
    results[i] = await worker(items[i], i);
    await runNext();
  }

  const runners = Array.from({ length: Math.min(concurrency, items.length) }, runNext);
  await Promise.all(runners);
  return results;
}

module.exports = { mapWithConcurrency };
