# Creator Leads

A YouTube creator prospecting tool for Pehchaan Media. Finds channels that would
benefit from a thumbnail redesign, scores their thumbnails with Gemini, and tracks
them through a simple outreach pipeline.

Built as a single Node/Express app on purpose — no monorepo, no ORM, no external
database. The whole dataset is one JSON file (`data/leads.json`). That's a
deliberate choice: it means zero setup cost, nothing to provision on Replit, and
nothing that can silently rack up a bill. If you outgrow it later (hundreds of
leads, multiple people editing at once), swap `src/db.js` for a real database —
every route talks to `src/db.js` through the same five functions, so that's the
only file that would need to change.

## Setup

1. `npm install`
2. Copy `.env.example` to `.env` and fill in:
   - `YOUTUBE_API_KEY` — required. From Google Cloud Console, with "YouTube Data
     API v3" enabled on the project.
   - `GEMINI_API_KEY` — optional. From Google AI Studio. Without it, thumbnail
     scoring is skipped and every lead gets a neutral placeholder score you can
     fill in later by adding the key and hitting "Score" again.
3. `npm start`
4. Open the app at whatever port it prints (5000 by default).

## On Replit

1. Import this folder (or its GitHub repo) as a new Repl — it auto-detects
   Node.js.
2. Add `YOUTUBE_API_KEY` and `GEMINI_API_KEY` under Replit's Secrets panel
   (padlock icon in the sidebar), not in a committed `.env` file.
3. Hit Run. Replit sets `PORT` automatically.
4. `data/leads.json` will persist across restarts as long as you're on a Repl
   with persistent storage (any paid or "Always On" plan). On the free tier,
   the filesystem can reset when the Repl goes to sleep — export to CSV
   periodically if that matters to you, or move to Replit's built-in Postgres
   later if you want guaranteed persistence.

## Why this design

**Quota-efficient by default.** The most expensive YouTube API call
(`search.list`, 100 quota units) is made exactly once per search, no matter how
many channels come back. Channel upload history comes from each channel's
"uploads" playlist (`playlistItems.list`, 1 unit) instead of another
`search.list` call. A search that used to cost 2,000+ units now costs under 150.
Default daily quota is 10,000 units, so you get dozens of searches a day instead
of four or five.

**City-level location is best-effort, and the UI says so.** YouTube's API only
exposes a channel's self-declared country, never a city. When you enter a city,
it's folded into the search keywords and also checked against the channel's
About description as a soft signal — it's a helpful filter, not a guarantee.
Worth knowing before you rely on it for a specific city's creators.

**Gemini image scoring sends real image bytes.** Thumbnails are downloaded and
base64-encoded before being sent to Gemini as `inlineData`. A bare image URL
doesn't work with Gemini's API — that was the bug in the previous version of
this tool, and every score it produced was actually a random fallback number.

**Model name is an env var, not a hardcoded string.** `GEMINI_MODEL` defaults to
`gemini-2.5-flash`. Google has been retiring Gemini model generations on a
rolling schedule through 2026 — when the next one lands, change the env var,
not the code.

## Outreach emails

Each lead has an "Email" button that generates a ready-to-send cold email using
Pehchaan Media's actual offer and the specific thumbnail weakness Gemini found
for that channel. It's a plain template, not an AI call, so it's instant and
free. Copy it and send it however you outreach (email client, DM, whatever).

## What's deliberately not included (yet)

- No user accounts / auth — this is a single-operator internal tool.
- No background job queue — discovery runs synchronously. With the quota fix
  above, a 10-20 channel search finishes in a few seconds, so this hasn't been
  a problem in testing. If you push `resultsWanted` much higher and turn on
  AI scoring for all of them, expect it to take longer since scoring calls are
  paced to stay under Gemini's free-tier rate limit.
- No revenue/CPM tier estimate — the previous version of this tool had one and
  it doesn't map to anything you actually asked for this rebuild. Add it back
  in `src/routes/search.js` if you decide you want it.
