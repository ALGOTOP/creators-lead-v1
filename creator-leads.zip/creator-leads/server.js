require("dotenv").config();
const express = require("express");
const path = require("path");

const searchRoutes = require("./src/routes/search");
const leadsRoutes = require("./src/routes/leads");
const statsRoutes = require("./src/routes/stats");

const app = express();

const required = ["YOUTUBE_API_KEY"];
const missing = required.filter((k) => !process.env[k]);
if (missing.length > 0) {
  console.warn(
    `Warning: missing env vars: ${missing.join(", ")}. Discovery search will fail until these are set (as Replit Secrets or in .env).`
  );
}
if (!process.env.GEMINI_API_KEY) {
  console.warn("Note: GEMINI_API_KEY not set. Thumbnail scoring will use the neutral fallback score until it's added.");
}

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.use("/api", searchRoutes);
app.use("/api", leadsRoutes);
app.use("/api", statsRoutes);

app.get("/api/health", (_req, res) => res.json({ ok: true }));

const port = Number(process.env.PORT) || 5000;
app.listen(port, () => {
  console.log(`Creator Leads running on port ${port}`);
});
